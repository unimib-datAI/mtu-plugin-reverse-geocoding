### Reverse Geocoding Transform

`Reverse Geocoding` plugin converts a column of geocoordinates to the corresponding string address of the place.